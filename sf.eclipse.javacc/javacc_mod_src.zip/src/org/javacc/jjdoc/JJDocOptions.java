/* Copyright (c) 2005-2006, Kees Jan Koster kjkoster@kjkoster.org
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Sun Microsystems, Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.javacc.jjdoc;

import org.javacc.parser.Options;

/**
 * The options, specific to JJDoc.
 * 
 * @author Kees Jan Koster &lt;kjkoster@kjkoster.org&gt;
 */
public class JJDocOptions extends Options {

    /**
     * Limit subclassing to derived classes.
     */
    protected JJDocOptions() {
        super();
    }

    /**
     * Initialize the options.
     */
    public static void init() {
        Options.init();

        optionValues.put("ONE_TABLE", Boolean.TRUE);
        optionValues.put("TEXT", Boolean.FALSE);

        optionValues.put("OUTPUT_FILE", "");
        optionValues.put("JJDOC_OUTPUT_FILE", "");
        optionValues.put("CSS", "");
        
        optionValues.put("INPUT_FILE", "");
        optionValues.put("JJDOC_OUTPUT_DIRECTORY", ".");
        
        // To parse JavaCC files without warnings
        optionValues.put("LOOKAHEAD", new Integer(1));
        optionValues.put("CHOICE_AMBIGUITY_CHECK", new Integer(2));
        optionValues.put("OTHER_AMBIGUITY_CHECK", new Integer(1));
        optionValues.put("STATIC", Boolean.TRUE);
        optionValues.put("DEBUG_PARSER", Boolean.FALSE);
        optionValues.put("DEBUG_LOOKAHEAD", Boolean.FALSE);
        optionValues.put("DEBUG_TOKEN_MANAGER", Boolean.FALSE);
        optionValues.put("ERROR_REPORTING", Boolean.TRUE);
        optionValues.put("JAVA_UNICODE_ESCAPE", Boolean.FALSE);
        optionValues.put("UNICODE_INPUT", Boolean.FALSE);
        optionValues.put("IGNORE_CASE", Boolean.FALSE);
        optionValues.put("USER_TOKEN_MANAGER", Boolean.FALSE);
        optionValues.put("USER_CHAR_STREAM", Boolean.FALSE);
        optionValues.put("BUILD_PARSER", Boolean.TRUE);
        optionValues.put("BUILD_TOKEN_MANAGER", Boolean.TRUE);
        optionValues.put("TOKEN_MANAGER_USES_PARSER", Boolean.FALSE);
        optionValues.put("SANITY_CHECK", Boolean.TRUE);
        optionValues.put("FORCE_LA_CHECK", Boolean.FALSE);
        optionValues.put("COMMON_TOKEN_ACTION", Boolean.FALSE);
        optionValues.put("CACHE_TOKENS", Boolean.FALSE);
        optionValues.put("KEEP_LINE_COLUMN", Boolean.TRUE);
        optionValues.put("OUTPUT_DIRECTORY", ".");
        optionValues.put("JDK_VERSION", "1.4");
        
        // To parse JJTree files without warnings
        optionValues.put("JDK_VERSION", "1.4");
        optionValues.put("MULTI", Boolean.FALSE);
        optionValues.put("NODE_DEFAULT_VOID", Boolean.FALSE);
        optionValues.put("NODE_SCOPE_HOOK", Boolean.FALSE);
        optionValues.put("NODE_FACTORY", Boolean.FALSE);
        optionValues.put("NODE_USES_PARSER", Boolean.FALSE);
        optionValues.put("BUILD_NODE_FILES", Boolean.TRUE);
        optionValues.put("VISITOR", Boolean.FALSE);
        optionValues.put("NODE_PREFIX", "AST");
        optionValues.put("NODE_PACKAGE", "");
        optionValues.put("NODE_EXTENDS", "");
        optionValues.put("OUTPUT_FILE", "");
        optionValues.put("VISITOR_EXCEPTION", "");
        optionValues.put("JJTREE_OUTPUT_DIRECTORY", "");
    }

    /**
     * Find the one table value.
     * 
     * @return The requested one table value.
     */
    public static boolean getOneTable() {
        return booleanValue("ONE_TABLE");
    }

    /**
     * Find the CSS value.
     *
     * @return The requested CSS value.
     */
    public static String getCSS() {
        return stringValue("CSS");
    }

    /**
     * Find the text value.
     * 
     * @return The requested text value.
     */
    public static boolean getText() {
        return booleanValue("TEXT");
    }

    /**
     * Find the output file value.
     * 
     * @return The requested output value.
     */
    public static String getOutputFile() {
      // Backward compatible if OUTPUT_FILE is used instead of JJDOC_OUTPUT_FILE
      if (stringValue("JJDOC_OUTPUT_FILE").equals(""))
        return stringValue("OUTPUT_FILE");
      else
        return stringValue("JJDOC_OUTPUT_FILE");
    }
    
    /**
     * Find the output directory.
     * 
     * @return The requested output directory.
     */
    public static java.io.File getOutputDirectory() {
        return new java.io.File(stringValue("JJDOC_OUTPUT_DIRECTORY"));
    }
}
